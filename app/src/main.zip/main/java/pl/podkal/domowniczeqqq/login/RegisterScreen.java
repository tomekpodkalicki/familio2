package pl.podkal.domowniczeqqq.login;

import android.app.Activity;

public class RegisterScreen extends Activity {
}
