package pl.podkal.domowniczeqqq.ui.theme


import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyApplication : Application() {
    // You can perform global initialization here if needed
}
