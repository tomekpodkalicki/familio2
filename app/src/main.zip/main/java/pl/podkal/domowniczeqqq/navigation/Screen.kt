package pl.podkal.domowniczeqqq.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import pl.podkal.domowniczeqqq.home.auth

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home_screen", "Kalendarz", Icons.Filled.CalendarMonth)
    object Profile : Screen("finance", "Finance", Icons.Filled.Money)
    object Settings : Screen("notes_screen", "Notatki", Icons.Filled.NoteAlt)
    object Receipts : Screen("receipts", "Multimedia", Icons.Filled.PhotoLibrary)
}
