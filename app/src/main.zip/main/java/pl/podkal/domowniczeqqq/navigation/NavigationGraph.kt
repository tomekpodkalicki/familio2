package pl.podkal.domowniczeqqq.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import pl.podkal.domowniczeqqq.finanse.FinanceScreen
import pl.podkal.domowniczeqqq.home.HomeScreen
import pl.podkal.domowniczeqqq.home.auth
import pl.podkal.domowniczeqqq.login.LoginScreen
import pl.podkal.domowniczeqqq.login.LoginViewModel
import pl.podkal.domowniczeqqq.notes.ArchiveScreen
import pl.podkal.domowniczeqqq.notes.NotesScreen
import pl.podkal.domowniczeqqq.receipts.ReceiptsScreen
import pl.podkal.domowniczeqqq.register.RegisterScreen


@Composable
fun NavigationGraph(navController: NavHostController) {
    val loginViewModel: LoginViewModel = hiltViewModel()
    loginViewModel.savedStateHandle.get<String>("navigation_destination")
    val currentUser = auth.currentUser

    LaunchedEffect(Unit) {
        if (currentUser != null) {
            navController.navigate("home_screen") {
                popUpTo("login_screen") { inclusive = true }
            }
        } else {
            navController.navigate("login_screen") {
                popUpTo("home_screen") { inclusive = true }
            }
        }
    }
    NavHost(navController = navController, startDestination = "login_screen") {
        composable("login_screen") { LoginScreen(navController) }
        composable("register_screen") { RegisterScreen(navController) }
        composable("home_screen") { HomeScreen(navController) }
        composable("notes_screen") { NotesScreen(navController) }
        composable("receipts") { ReceiptsScreen(navController)}
        composable("finance") { FinanceScreen(navController) }
        composable("archive_screen") { ArchiveScreen(navController)


        }
    }
}
