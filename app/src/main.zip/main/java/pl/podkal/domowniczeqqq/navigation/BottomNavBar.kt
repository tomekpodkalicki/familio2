package pl.podkal.domowniczeqqq.navigation

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.BottomNavigation
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

private val FamilioTeal = Color(0xFF1ABC9C)

@Composable
fun BottomNavBar(navController: NavController) {
    val selectedContentColor = Color.White
    val unselectedContentColor = Color.LightGray

    val items = listOf(
        Screen.Home,
        Screen.Profile,
        Screen.Settings,
        Screen.Receipts
    )

    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    BottomNavigation(
        backgroundColor = FamilioTeal,
        contentColor = selectedContentColor,
        modifier = Modifier.clip(CircleShape)
    ) {
        items.forEach { screen ->
            BottomNavigationItem(
                icon = { Icon(imageVector = screen.icon, contentDescription = screen.title) },
                label = { Text(screen.title) },
                selected = currentRoute == screen.route,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.startDestinationRoute ?: Screen.Home.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                selectedContentColor = selectedContentColor,
                unselectedContentColor = unselectedContentColor
            )
        }
    }
}

@Preview
@Composable
fun previewBottom() {
    BottomNavBar(navController = rememberNavController())
}
